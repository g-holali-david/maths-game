from jeu_de_maths import JeuMath
import tkinter as tk

def main():
    root = tk.Tk()
    jeu = JeuMath(root)
    root.mainloop()

if __name__ == "__main__":
    main()
