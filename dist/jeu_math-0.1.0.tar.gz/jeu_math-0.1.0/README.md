# Jeu de Questions Mathématiques

Ce projet est une application de jeu de questions mathématiques développée en Python avec Tkinter.

## Installation

Pour installer l'application, exécutez :

```bash
pip install .
